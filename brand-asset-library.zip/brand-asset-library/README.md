# 🎨 品牌资产共享库

> 一个用于团队共享品牌资产（爆款内容模板、风格模板等）的轻量级系统。
> 
> **特点：** 免费、无需服务器、自动版本控制、支持API接入

---

## 📦 项目结构

```
brand-asset-library/
├── assets/                    # 品牌资产存储目录（YAML格式）
│   └── ASSET-20260409-001.yaml  # 示例：暗黑风神圣感
├── templates/                 # 模板文件
│   └── asset_template.yaml    # 资产模板
├── utils/                     # 工具模块
│   └── asset_manager.py       # 资产管理器
├── app.py                     # Streamlit 主应用
├── requirements.txt           # Python 依赖
└── README.md                  # 本文件
```

---

## 🚀 部署指南（5分钟完成）

### 第一步：创建 GitHub 仓库

1. 登录 GitHub：https://github.com
2. 点击右上角 **+** → **New repository**
3. 填写信息：
   - Repository name: `brand-asset-library`
   - Description: `品牌资产共享库`
   - 选择 **Public**（公开，方便API访问）
   - ✅ 勾选 **Add a README file**
4. 点击 **Create repository**

### 第二步：上传项目文件

**方式A：网页上传（推荐小白）**

1. 在新创建的仓库页面，点击 **Add file** → **Upload files**
2. 将以下文件/文件夹拖拽上传：
   - `assets/` 文件夹（含示例资产）
   - `templates/` 文件夹
   - `utils/` 文件夹
   - `app.py`
   - `requirements.txt`
3. 点击 **Commit changes**

**方式B：Git 命令（如果你会用）**

```bash
# 克隆仓库
git clone https://github.com/你的用户名/brand-asset-library.git
cd brand-asset-library

# 复制项目文件到此处
# ...

# 提交并推送
git add .
git commit -m "初始化品牌资产库"
git push origin main
```

### 第三步：部署到 Streamlit Cloud

1. 访问 Streamlit Cloud：https://share.streamlit.io
2. 使用 GitHub 账号登录
3. 点击 **New app**
4. 填写信息：
   - Repository: `你的用户名/brand-asset-library`
   - Branch: `main`
   - Main file path: `app.py`
5. 点击 **Deploy!**
6. 等待 1-2 分钟，部署成功后会自动打开应用

**部署完成后，你会获得一个永久访问链接：**
```
https://你的应用名.streamlit.app
```

---

## 📖 使用说明

### 资产浏览

- 点击左侧 **📚 资产浏览**
- 可按产品、作者筛选
- 点击资产卡片查看详情
- 可下载 YAML 文件

### 创建资产

1. 点击左侧 **➕ 创建资产**
2. 填写必填项（带 * 标记）：
   - 资产名称
   - 上传者
   - 产品
   - 活动名称
   - 标签（逗号分隔）
   - 内容结构（至少一个阶段）
   - 爆款案例（至少一个）
3. 点击 **✅ 创建资产**

> **注意：** Streamlit Cloud 是免费托管，资产数据保存在容器内存中，重启会丢失。要持久化存储，需要配置 GitHub 自动提交（见下方）。

### 搜索资产

- **关键词搜索：** 输入关键词，搜索资产名称和标签
- **标签匹配：** 选择标签，查找包含这些标签的资产
- **相似推荐：** 选择一个资产，系统推荐相似资产

---

## 🔌 龙虾 Agent API 接入

### 方法一：读取 GitHub Raw URL（推荐）

```python
import requests
import yaml

# 获取资产列表
url = "https://raw.githubusercontent.com/你的用户名/brand-asset-library/main/assets.json"
response = requests.get(url)
assets = response.json()

# 搜索暗黑风资产
dark_assets = [a for a in assets if '暗黑风' in a.get('tags', [])]

# 获取单个资产详情
asset_id = "ASSET-20260409-001"
asset_url = f"https://raw.githubusercontent.com/你的用户名/brand-asset-library/main/assets/{asset_id}.yaml"
response = requests.get(asset_url)
asset = yaml.safe_load(response.text)
```

### 方法二：克隆仓库后本地读取

```python
from utils.asset_manager import AssetManager

manager = AssetManager(assets_dir="assets")

# 列出所有资产
assets = manager.list_assets()

# 按标签搜索
results = manager.list_assets(filters={'tags': ['暗黑风']})

# 查找相似资产
similar = manager.search_similar_assets(['暗黑风', '神圣感'])
```

### API URL 格式

| 资源 | URL |
|------|-----|
| 资产列表 JSON | `https://raw.githubusercontent.com/{用户}/{仓库}/main/assets.json` |
| 单个资产 YAML | `https://raw.githubusercontent.com/{用户}/{仓库}/main/assets/{资产ID}.yaml` |

---

## 🔄 持久化存储配置（进阶）

Streamlit Cloud 默认不保存文件，要实现持久化存储，有两种方案：

### 方案A：GitHub 自动提交（推荐）

在 `utils/` 下添加 `github_sync.py`，每次创建资产自动提交到 GitHub：

```python
import requests
import base64

def commit_to_github(file_path, content, token, repo, branch="main"):
    """提交文件到GitHub"""
    url = f"https://api.github.com/repos/{repo}/contents/{file_path}"
    
    # 获取当前文件SHA（用于更新）
    response = requests.get(url, headers={"Authorization": f"token {token}"})
    sha = response.json().get('sha') if response.status_code == 200 else None
    
    data = {
        "message": f"Update {file_path}",
        "content": base64.b64encode(content.encode()).decode(),
        "branch": branch
    }
    if sha:
        data["sha"] = sha
    
    response = requests.put(
        url, 
        headers={"Authorization": f"token {token}"},
        json=data
    )
    return response.status_code == 200
```

**使用：**
1. 创建 GitHub Personal Access Token（Settings → Developer settings → Personal access tokens）
2. 在 Streamlit Cloud 的 Secrets 中添加：
   ```toml
   GITHUB_TOKEN = "你的token"
   GITHUB_REPO = "你的用户名/brand-asset-library"
   ```
3. 修改 `app.py`，保存资产时调用 `commit_to_github`

### 方案B：Streamlit Cloud 数据库

使用 Streamlit Cloud 的持久化数据库：
```python
import streamlit as st

# 使用 session_state 临时存储
if 'assets' not in st.session_state:
    st.session_state.assets = []
```

---

## 📋 资产模板说明

品牌资产包含以下核心字段：

| 字段 | 必填 | 说明 |
|------|------|------|
| name | ✅ | 资产名称，如"暗黑风+神圣感" |
| author | ✅ | 上传者邮箱或姓名 |
| source | ✅ | 来源信息（活动名称、产品、时间段） |
| tags | ✅ | 标签列表，用于搜索和分类 |
| content_structure | ✅ | 内容结构模板（开场/转场/呈现/收尾） |
| top_cases | ✅ | 爆款案例列表 |
| character_traits | | 适用角色特征 |
| visual_elements | | 可复用的视觉元素 |
| transition_methods | | 转场方式库 |
| copywriting_styles | | 文案风格库 |
| notes | | 注意事项 |
| reuse_suggestions | | 复用建议 |

---

## 🤝 团队协作

### 添加协作者

1. 在 GitHub 仓库页面，点击 **Settings**
2. 左侧选择 **Collaborators**
3. 点击 **Add people**
4. 输入同事的 GitHub 用户名或邮箱
5. 选择权限：**Write**（可读写）或 **Read**（只读）

### 使用流程

1. 访问 Streamlit 应用：`https://你的应用名.streamlit.app`
2. 浏览/搜索已有资产
3. 点击 **➕ 创建资产** 添加新的品牌资产
4. 资产自动保存到 GitHub（如已配置持久化）

---

## 🛠️ 本地运行（开发调试）

```bash
# 克隆仓库
git clone https://github.com/你的用户名/brand-asset-library.git
cd brand-asset-library

# 安装依赖
pip install -r requirements.txt

# 运行应用
streamlit run app.py
```

---

## 📞 技术支持

- **问题反馈：** 在 GitHub 仓库创建 Issue
- **功能建议：** 同上

---

## 📜 更新日志

- **v1.0 (2026-04-09):** 初始版本
  - 资产浏览/创建/搜索功能
  - Streamlit Cloud 部署支持
  - GitHub API 接入指南
  - 示例资产：暗黑风神圣感

---

<div align="center">

**🎨 品牌资产共享库**

让爆款经验成为团队财富

</div>
