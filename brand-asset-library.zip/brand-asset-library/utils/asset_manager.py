"""
品牌资产管理器
负责资产的读取、验证、保存等操作
"""

import os
import yaml
import json
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path


class AssetManager:
    """品牌资产管理器"""
    
    def __init__(self, assets_dir: str = "assets"):
        """
        初始化资产管理器
        
        Args:
            assets_dir: 资产存储目录
        """
        self.assets_dir = Path(assets_dir)
        self.assets_dir.mkdir(parents=True, exist_ok=True)
        
    def load_asset(self, asset_id: str) -> Optional[Dict]:
        """
        加载单个资产
        
        Args:
            asset_id: 资产ID
            
        Returns:
            资产数据字典，不存在则返回None
        """
        file_path = self.assets_dir / f"{asset_id}.yaml"
        if not file_path.exists():
            return None
            
        with open(file_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    def list_assets(self, filters: Optional[Dict] = None) -> List[Dict]:
        """
        列出所有资产，支持筛选
        
        Args:
            filters: 筛选条件
                - author: 作者
                - tags: 标签列表（任一匹配）
                - product: 产品名
                - keyword: 关键词搜索（名称、标签）
                
        Returns:
            资产列表
        """
        assets = []
        
        for file_path in self.assets_dir.glob("*.yaml"):
            with open(file_path, 'r', encoding='utf-8') as f:
                asset = yaml.safe_load(f)
                if asset:
                    assets.append(asset)
        
        # 按创建时间倒序
        assets.sort(key=lambda x: x.get('created_at', ''), reverse=True)
        
        # 应用筛选
        if filters:
            assets = self._apply_filters(assets, filters)
            
        return assets
    
    def _apply_filters(self, assets: List[Dict], filters: Dict) -> List[Dict]:
        """应用筛选条件"""
        result = assets
        
        # 作者筛选
        if filters.get('author'):
            result = [a for a in result if a.get('author') == filters['author']]
        
        # 产品筛选
        if filters.get('product'):
            result = [
                a for a in result 
                if a.get('source', {}).get('product') == filters['product']
            ]
        
        # 标签筛选（任一匹配）
        if filters.get('tags'):
            filter_tags = set(filters['tags'])
            result = [
                a for a in result
                if filter_tags & set(a.get('tags', []))
            ]
        
        # 关键词搜索
        if filters.get('keyword'):
            keyword = filters['keyword'].lower()
            result = [
                a for a in result
                if keyword in a.get('name', '').lower()
                or any(keyword in t.lower() for t in a.get('tags', []))
            ]
        
        return result
    
    def save_asset(self, asset_data: Dict) -> str:
        """
        保存资产
        
        Args:
            asset_data: 资产数据
            
        Returns:
            资产ID
        """
        # 生成资产ID
        if not asset_data.get('asset_id'):
            today = datetime.now().strftime('%Y%m%d')
            existing = list(self.assets_dir.glob(f"ASSET-{today}-*.yaml"))
            next_num = len(existing) + 1
            asset_data['asset_id'] = f"ASSET-{today}-{next_num:03d}"
        
        # 更新时间戳
        asset_data['updated_at'] = datetime.now().strftime('%Y-%m-%d')
        if not asset_data.get('created_at'):
            asset_data['created_at'] = asset_data['updated_at']
        
        # 验证必填字段
        self._validate_asset(asset_data)
        
        # 保存文件
        file_path = self.assets_dir / f"{asset_data['asset_id']}.yaml"
        with open(file_path, 'w', encoding='utf-8') as f:
            yaml.dump(asset_data, f, allow_unicode=True, sort_keys=False)
        
        return asset_data['asset_id']
    
    def _validate_asset(self, asset_data: Dict):
        """验证资产数据完整性"""
        required_fields = ['name', 'author', 'source', 'tags', 'content_structure', 'top_cases']
        
        missing = [f for f in required_fields if not asset_data.get(f)]
        if missing:
            raise ValueError(f"缺少必填字段: {', '.join(missing)}")
        
        # 验证source
        source = asset_data.get('source', {})
        if not source.get('campaign_name'):
            raise ValueError("source.campaign_name 为必填项")
        
        # 验证tags
        if not asset_data.get('tags') or len(asset_data['tags']) == 0:
            raise ValueError("tags 至少需要一项")
        
        # 验证content_structure
        if not asset_data.get('content_structure') or len(asset_data['content_structure']) == 0:
            raise ValueError("content_structure 至少需要一项")
        
        # 验证top_cases
        if not asset_data.get('top_cases') or len(asset_data['top_cases']) == 0:
            raise ValueError("top_cases 至少需要一项")
    
    def delete_asset(self, asset_id: str) -> bool:
        """
        删除资产
        
        Args:
            asset_id: 资产ID
            
        Returns:
            是否删除成功
        """
        file_path = self.assets_dir / f"{asset_id}.yaml"
        if file_path.exists():
            file_path.unlink()
            return True
        return False
    
    def get_statistics(self) -> Dict:
        """
        获取资产库统计信息
        
        Returns:
            统计数据
        """
        assets = self.list_assets()
        
        # 统计标签分布
        tag_counts = {}
        for asset in assets:
            for tag in asset.get('tags', []):
                tag_counts[tag] = tag_counts.get(tag, 0) + 1
        
        # 统计作者分布
        author_counts = {}
        for asset in assets:
            author = asset.get('author', 'unknown')
            author_counts[author] = author_counts.get(author, 0) + 1
        
        # 统计产品分布
        product_counts = {}
        for asset in assets:
            product = asset.get('source', {}).get('product', 'unknown')
            product_counts[product] = product_counts.get(product, 0) + 1
        
        return {
            'total_assets': len(assets),
            'tag_distribution': tag_counts,
            'author_distribution': author_counts,
            'product_distribution': product_counts,
        }
    
    def export_to_json(self, output_path: str):
        """
        导出所有资产为JSON格式（供API使用）
        
        Args:
            output_path: 输出文件路径
        """
        assets = self.list_assets()
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(assets, f, ensure_ascii=False, indent=2)
    
    def search_similar_assets(self, tags: List[str], limit: int = 5) -> List[Dict]:
        """
        搜索相似资产（基于标签匹配度）
        
        Args:
            tags: 查询标签
            limit: 返回数量限制
            
        Returns:
            相似资产列表，按匹配度排序
        """
        assets = self.list_assets()
        query_tags = set(tags)
        
        # 计算每个资产的匹配分数
        scored_assets = []
        for asset in assets:
            asset_tags = set(asset.get('tags', []))
            # Jaccard 相似度
            intersection = len(query_tags & asset_tags)
            union = len(query_tags | asset_tags)
            score = intersection / union if union > 0 else 0
            
            if score > 0:
                scored_assets.append((score, asset))
        
        # 按分数排序
        scored_assets.sort(key=lambda x: x[0], reverse=True)
        
        return [a for _, a in scored_assets[:limit]]
